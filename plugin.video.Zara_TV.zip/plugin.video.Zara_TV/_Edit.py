import xbmcaddon

MainBase = 'https://goo.gl/EwTqgc'
addon = xbmcaddon.Addon('plugin.video.Zara_TV')